import {
  AngularFireModule,
  FIREBASE_APP_NAME,
  FIREBASE_OPTIONS,
  FirebaseApp,
  ɵapplyMixins,
  ɵcacheInstance,
  ɵfirebaseAppFactory,
  ɵlazySDKProxy
} from "./chunk-IHKIHAV6.js";
import "./chunk-I4KZKQGV.js";
import "./chunk-Z2J4JONH.js";
import "./chunk-IAV4BMDW.js";
import "./chunk-NSAKKRKK.js";
import "./chunk-YKIP3M2L.js";
import "./chunk-WCLAHN6D.js";
export {
  AngularFireModule,
  FIREBASE_APP_NAME,
  FIREBASE_OPTIONS,
  FirebaseApp,
  ɵapplyMixins,
  ɵcacheInstance,
  ɵfirebaseAppFactory,
  ɵlazySDKProxy
};
//# sourceMappingURL=@angular_fire_compat.js.map
