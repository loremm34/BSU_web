import { Component } from '@angular/core';
import { Prescriptions } from '../services/mock-prescriptions-list';

@Component({
  selector: 'app-prescriptions-center',
  templateUrl: './prescriptions-center.component.html',
  styleUrl: './prescriptions-center.component.sass',
})
export class PrescriptionsCenterComponent {}
