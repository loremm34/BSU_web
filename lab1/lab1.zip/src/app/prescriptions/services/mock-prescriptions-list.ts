export interface Prescriptions {
  id: string;
  description: string;
  doctor: string;
  patient: string;
}

export const Prescriptionss: Prescriptions[] = [
  { id: '1', description: 'Pill', doctor: 'Bob2', patient: 'Bob1' },
  { id: '2', description: 'Pill', doctor: 'Bob2', patient: 'Bob1' },
  { id: '3', description: 'Pill', doctor: 'Bob2', patient: 'Bob1' },
  { id: '4', description: 'Pill', doctor: 'Bob2', patient: 'Bob1' },
  { id: '5', description: 'Pill', doctor: 'Bob2', patient: 'Bob1' },
  { id: '6', description: 'Pill', doctor: 'Bob2', patient: 'Bob1' },
];
