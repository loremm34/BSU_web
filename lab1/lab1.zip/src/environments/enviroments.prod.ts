export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: 'AIzaSyAxnlP5sYDznlPWQN1mfLpXoPeASA6xH9o',
    authDomain: 'weblab1-d3d1d.firebaseapp.com',
    projectId: 'weblab1-d3d1d',
    storageBucket: 'weblab1-d3d1d.appspot.com',
    messagingSenderId: '891701820913',
    appId: '1:891701820913:web:c59e92308b5f71e0cd5850',
  },
};
